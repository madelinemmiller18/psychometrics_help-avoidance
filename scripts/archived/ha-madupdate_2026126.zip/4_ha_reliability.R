# 1. I ask my group members to explain concepts that confuse me [-]
# 2. If I do not understand, I will be quieter in group project meetings [+]
# 3. If I am struggling with my project contributions, I seek support from my group members [-]
# 4. When I am unsure about my work, I am reluctant to seek feedback from my group [+]
# 5. If a project is too hard for me, I participate less rather than ask my group for help [+]
# 6. I avoid asking my group members for help even when I find my task difficult. [+]
# 7. I pretend to understand group project discussions even when I feel confused. [+]
# 8. I hesitate to ask my teammates for clarification during group projects. [+]
# 9. I tend to keep working on my own even when collaborating with my group would make the task easier [+]

################################################################
################################################################
################################################################
# SESSION 4: Reliability
################################################################
################################################################
################################################################

#set working directory
print(getwd())
path="~/Desktop/psychometrics_foundations/psychometrics_help-avoidance"
figures_path = "~/Desktop/psychometrics_foundations/psychometrics_help-avoidance/figures/cfa/"
setwd(path)
#setwd("E:\\OneDrive - UT Cloud\\UniLife\\M1 Semester1\\3_Psychometrics\\HA_Project")


library(psych)
library(lavaan) #  library for CFA and structural equation modeling (SEM)
# needed for the calculation of omega
library(dplyr)

###############################################################
# set up data
###############################################################
# upload data
rawdata <- read.csv("data/Help Avoidance in Group Projects.csv")
df <- rawdata[c(3:14)]

# change column names
df <- df %>%
  rename(
    explain_hs = "I.ask.my.group.members.to.explain.concepts.that.confuse.me.",
    quiet_ha = "If.I.do.not.understand..I.will.be.quieter.in.group.project.meetings.",
    support_hs = "If.I.am.struggling.with.my.project.contributions..I.seek.support.from.my.group.members.",
    feedback_ha = "When.I.am.unsure.about.my.work..I.am.reluctant.to.seek.feedback.from.my.group.",
    participation_ha = "If.a.project.is.too.hard.for.me..I.participate.less.rather.than.ask.my.group.for.help.",
    taskhelp_ha = "I.avoid.asking.my.group.members.for.help.even.when.I.find.my.task.difficult.",
    pretunderstand_ha = "I.pretend.to.understand.group.project.discussions.even.when.I.feel.confused..",
    clarification_ha = "I.hesitate.to.ask.my.teammates.for.clarification.during.group.projects.",
    workown_ha = "I.tend.to.keep.working.on.my.own.even.when.collaborating.with.my.group.would.make.the.task.easier.",
    degree_level = "What.is.your.current.student.status.",
    fos = "Which.field.best.describes.your.area.of.study.",
    langlevel = "Self.rate.your.skills.in.the.language.typically.used.for.your.group.projects..e.g...German.or.English.."
  )


#degree level numerical encoding
# (1 = Bachelor/MD/Medical, 2 = Master, 3 = PhD)
# Classify as 1 (Undergraduate or equivalent)
unique(df$degree_level) #return unique values
df$degree_level[df$degree_level == "Undergraduate Student (Bachelor or equivalent)"] <- 1
df$degree_level[df$degree_level  == "MD"] <- 1
df$degree_level[df$degree_level  == "Medical Student"] <- 1
# Classify as 2 (Master or equivalent)
df$degree_level[df$degree_level == "Graduate Student (Master or equivalent)"] <- 2
# Classify as 3 (Doctoral or equivalent)
df$degree_level[df$degree_level == "Doctoral Student (PhD or equivalent)"] <- 3

#language level self rating numerical encoding 
unique(df$langlevel) #return unique values
df$langlevel[df$langlevel == "Less than adequate"]<-1
df$langlevel[df$langlevel == "Adequate"] <- 2  
df$langlevel[df$langlevel == "Good"]<-3
df$langlevel[df$langlevel == "Excellent"]<-4
df$langlevel[df$langlevel == "Native Speaker"]<-5

#fos numerical encoding 
unique(df$fos) #return unique values
df$fos[df$fos=="Economics and Social Sciences"]<-1
df$fos[df$fos=="Theology"]<-2
df$fos[df$fos=="Science"]<-3
df$fos[df$fos=="Humanities"]<-4
df$fos[df$fos=="Medicine"]<-5
#assign data science to economics and social sciences
df$fos[df$fos=="Data Science"]<-1
#assign rhetorics, philospophy to humanities
df$fos[df$fos=="Rhetorics, philosophy "]<-4

# save the relevant item labels
item_names <- colnames(df[1:9])

# all your information should be saved in a data frame where the
# number of rows correspond to the number of participants
# and the number of columns to the number of items and covariates.
# Use some kind of id as column names (instead of the full questions),
# e.g. rename a single column: colnames(dat.sub)[1] <- "item1"
# or all columns: colnames(dat.sub) <- c("item1", "item2",...)
# The entries should be the item responses (values between 1 and 6)
# and some numerical encoding for the covariates


###############################################################
# ANALYSIS
###############################################################

# For now, we just use the item information, not the covariates
dfitems <- df[,item_names]
#correlation matrix
round(cor(dfitems), 2)
#explain_hs and support_hs should be reversed (negative).
# So, we re-code by subtracting the response value from
# the maximum score plus 1 (which is 7 in this case)
dfitems[,"explain_hs"] <- 7-dfitems[,"explain_hs"]
dfitems[,"support_hs"] <- 7-dfitems[,"support_hs"]


###############################################################
# Internal consistency with Cronbach's alpha
###############################################################

# Calculate for Cronbach's alpha for full scale 1
alpha(dfitems)
# raw_alpha std.alpha G6(smc) average_r S/N   ase mean   sd median_r
# 0.74      0.74    0.78      0.24 2.8 0.063  2.8 0.77     0.24

# raw_alpha = .74 > .7, acceptable
# -> Cronbach's alpha (raw alpha) is estimated to be 0.74 #CONFIRM WITH SOFIA: whcih is Cronbach's?
# 9 items help avoidance scale has acceptable internal consistency

#if any of the items are dropped, Cronbach's alpha decreases
# Deleting items makes things worse.

###############################################################
# Internal consistency with McDonald's Omega
###############################################################
# we focus on unidimensional constructs. the rest needs 
# too much explanation
?omega
# === 1. Test if scale is unidimensional ===
# Calculate omega from efa for scale 1
omegah(dfitems,nfactors = 1) # ignore the warnings
# relevant information: Omega Total = 0.74 
# -> equal to Cronbach's alpha, Baseline if we treat scale as unidimensional
# -> effect of different factor loadings (Omega accounts for unequal factor loadings)

# === 2. Test 2-factor model ===
omegah(dfitems,nfactors = 2)
# Omega Total = 0.79 across the two factors
# -> increased as expected according to previous results
# Omega Hierarchical = 0.35 indicates weak general factor


# === 3. CFA-based omega (1-factor) ===
# Calculate omega from cfa (see last week) for scale 1 
# Define the one factor model
model1 <- '
f1 =~ explain_hs + quiet_ha + support_hs + feedback_ha + participation_ha 
  + taskhelp_ha + pretunderstand_ha + clarification_ha + workown_ha 
'
# Perform cfa
cfa1 <- cfa(model1,dfitems,std.lv=T)
# Calculate omega based on structural equation model (SEM)
omegaFromSem(cfa1) # again ignore the warnings
# Omega Total  from a confirmatory model using sem =  0.82 
# -> this ignores any problems due to misfit, so it is likely
#    to overestimate the reliability (is this right)

# === 4. CFA-based omega (2-factor model from EFA) ===
# Calculate omega for the 2-factor model identified in CFA
# PA1: explain_hs, quiet_ha, participation_ha, pretunderstand_ha, clarification_ha
# PA2: support_hs, feedback_ha, taskhelp_ha, workown_ha
model2 <- '
pa1 =~ explain_hs + quiet_ha + participation_ha + pretunderstand_ha + clarification_ha
pa2 =~ support_hs + feedback_ha + taskhelp_ha + workown_ha
'
cfa2 <- cfa(model2,dfitems,std.lv=T)
omegaFromSem(cfa2)
# Omega Total  =  0.89 > .70, acceptable
# -> higher than Cronbach's alpha 0.74, higher than 1-factor CFA omega (0.82)

###############################################################
# Split half reliability
###############################################################

# The split half function produces a set of different indices
# by sampling repeatedly, using all possible splits for less
# than 16 items
splitHalf(dfitems)
# Maximum split half reliability (lambda 4) =  0.84, good reliability
# Average split half reliability            =  0.73, acceptable
# Minimum split half reliability  (beta)    =  0.45, varies a lot
